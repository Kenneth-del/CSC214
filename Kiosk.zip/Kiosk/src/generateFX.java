
public class generateFX implements fXGenerate {

	@Override
	public void generateScene() {
		// TODO Auto-generated method stub

	}

	@Override
	public void makeWebView() {
		// TODO Auto-generated method stub

	}


}
