
public interface fXGenerate {
	public void generateScene();
	public void makeWebView();
}
